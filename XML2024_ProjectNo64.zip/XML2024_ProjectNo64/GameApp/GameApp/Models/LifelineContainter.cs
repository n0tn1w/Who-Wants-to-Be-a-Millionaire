﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameApp.Models
{
    public class LifelineContainter
    {
        public bool isFiftyFiftyUsed { get; set; } = false;
        public bool isPhoneAFriendUsed { get; set; } = false;
        public bool isAskTheAudienceUsed { get; set; } = false;
    }
}
